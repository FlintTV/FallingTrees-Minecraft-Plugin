package me.flintofficial;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class FallingTreesCommand implements CommandExecutor {

    private final fallingtrees plugin;

    public FallingTreesCommand(fallingtrees plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {

            if (!sender.hasPermission("fallingtrees.admin")) {
                sender.sendMessage("§cʏᴏᴜ ᴅᴏ ɴᴏᴛ ʜᴀᴠᴇ ᴘᴇʀᴍɪѕѕɪᴏɴ ᴛᴏ ᴇxᴇᴄᴜᴛᴇ ᴛʜɪѕ ᴄᴏᴍᴍᴀɴᴅ");
                return true;
            }

            plugin.reloadPluginConfig();
            sender.sendMessage(plugin.getReloadMessage().replace('&', '§'));
            return true;
        }
        sender.sendMessage("§ccorrect usage: §a/fallingtrees reload");
        return false;
    }
}
