package me.flintofficial;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Set;

public class PlacedBlockTracker implements Listener {

    private final Set<Location> placedLogLocations = new HashSet<>();

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        Material type = event.getBlockPlaced().getType();
        if (type.name().endsWith("_LOG") || type.name().endsWith("_WOOD")) {
            placedLogLocations.add(event.getBlockPlaced().getLocation());
        }
    }

    public boolean isPlaced(Location loc) {
        return placedLogLocations.contains(loc);
    }

    public void remove(Location loc) {
        placedLogLocations.remove(loc);
    }

    public void register(JavaPlugin plugin) {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }
}
