package me.flintofficial;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Queue;
import java.util.Set;

public class TreeCollapseListener implements Listener {

    private final JavaPlugin plugin;
    private final PlacedBlockTracker tracker;

    public TreeCollapseListener(JavaPlugin plugin, PlacedBlockTracker tracker) {
        this.plugin = plugin;
        this.tracker = tracker;
    }

    @EventHandler
    public void onLogBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        String typeName = block.getType().name();


        if (!(typeName.endsWith("_LOG") || typeName.endsWith("_WOOD"))) {
            return;
        }


        if (tracker.isPlaced(block.getLocation())) {
            tracker.remove(block.getLocation());
            return;
        }


        Set<Block> treeBlocks = getTreeBlocks(block);

        for (Block b : treeBlocks) {
            if (tracker.isPlaced(b.getLocation())) {
                tracker.remove(b.getLocation());
                continue;
            }
            b.breakNaturally();
        }


        String soundName = plugin.getConfig().getString("trees.sound", "");
        if (!soundName.isEmpty() && event.getPlayer() != null) {
            try {

                String cleanName = soundName.toUpperCase().replace("MINECRAFT:", "").replace('.', '_');
                Sound sound = Sound.valueOf(cleanName);
                event.getPlayer().playSound(event.getPlayer().getLocation(), sound, 1f, 1f);
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("[FallingTrees] Suono non valido nel config.yml: " + soundName);
            }
        }
    }

    private Set<Block> getTreeBlocks(Block start) {
        Set<Block> visited = new HashSet<>();
        Queue<Block> queue = new ArrayDeque<>();
        queue.add(start);

        while (!queue.isEmpty()) {
            Block current = queue.poll();
            if (visited.contains(current)) continue;

            String name = current.getType().name();

            if (!(name.endsWith("_LOG") || name.endsWith("_WOOD"))) {
                continue;
            }

            visited.add(current);

            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        Block neighbor = current.getRelative(dx, dy, dz);
                        if (!visited.contains(neighbor)) {
                            queue.add(neighbor);
                        }
                    }
                }
            }
        }

        return visited;
    }
}
