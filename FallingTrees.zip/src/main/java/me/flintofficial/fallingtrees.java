package me.flintofficial;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class fallingtrees extends JavaPlugin {

    private PlacedBlockTracker placedBlockTracker;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        placedBlockTracker = new PlacedBlockTracker();
        placedBlockTracker.register(this);

        Bukkit.getPluginManager().registerEvents(new TreeCollapseListener(this, placedBlockTracker), this);

        PluginCommand cmd = getCommand("fallingtrees");
        if (cmd != null) {
            cmd.setExecutor(new FallingTreesCommand(this));
        }

        Bukkit.getConsoleSender().sendMessage("§a  _____     _ _ _            _____                   ");
        Bukkit.getConsoleSender().sendMessage("§a |  ___|_ _| | (_)_ __   __ |_   _| __ ___  ___  ___ ");
        Bukkit.getConsoleSender().sendMessage("§a | |_ / _` | | | | '_ \\ / _` || || '__/ _ \\/ _ \\/ __|");
        Bukkit.getConsoleSender().sendMessage("§a |  _| (_| | | | | | | | (_| || || |  __/  __/\\__ \\");
        Bukkit.getConsoleSender().sendMessage("§a |_|  \\__,_|_|_|_|_| |_|\\__, ||_||_|  \\___|\\___||___/");
        Bukkit.getConsoleSender().sendMessage("§a                        |___/                        ");
        Bukkit.getConsoleSender().sendMessage("§8Author: §b§l@FlintTV");
        Bukkit.getConsoleSender().sendMessage("§8Version: §b§l1.0.0");
        Bukkit.getConsoleSender().sendMessage("§8§lPlugin: §a§lENABLED");
    }

    @Override
    public void onDisable() {
        Bukkit.getConsoleSender().sendMessage("§c  _____     _ _ _            _____                   ");
        Bukkit.getConsoleSender().sendMessage("§c |  ___|_ _| | (_)_ __   __ |_   _| __ ___  ___  ___ ");
        Bukkit.getConsoleSender().sendMessage("§c | |_ / _` | | | | '_ \\ / _` || || '__/ _ \\/ _ \\/ __|");
        Bukkit.getConsoleSender().sendMessage("§c |  _| (_| | | | | | | | (_| || || |  __/  __/\\__ \\");
        Bukkit.getConsoleSender().sendMessage("§c |_|  \\__,_|_|_|_|_| |_|\\__, ||_||_|  \\___|\\___||___/");
        Bukkit.getConsoleSender().sendMessage("§c                        |___/                        ");
        Bukkit.getConsoleSender().sendMessage("§8Author: §b§l@FlintTV");
        Bukkit.getConsoleSender().sendMessage("§8Version: §b§l1.0.0");
        Bukkit.getConsoleSender().sendMessage("§8§lPlugin: §c§lDISABLED");
    }

    public PlacedBlockTracker getPlacedBlockTracker() {
        return placedBlockTracker;
    }

    public String getReloadMessage() {
        return getConfig().getString("reload_message", "&aConfig ricaricato con successo");
    }

    public void reloadPluginConfig() {
        reloadConfig();
        saveConfig();
        String msg = getReloadMessage();
        Bukkit.getConsoleSender().sendMessage(msg.replace('&', '§'));
    }
}
